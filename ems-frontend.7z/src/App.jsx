import './App.css'
import AddRecipientForm from './components/AddRecipientForm'
import AccountProfile from './components/AccountProfile'
import Security from './components/Security'
import MoneyExchange from './components/MoneyExchange'
import Layout from './components/Layout'
import EmployeeComponent from './components/EmployeeComponent'
import FooterComponent from './components/FooterComponent'
import HeaderComponent from './components/HeaderComponent'
import Login from './components/Login'
import Signup from './components/Signup'

import Header from './components/Header'

import TransferForm from './components/TransferForm'
import ListEmployeeComponent from './components/ListEmployeeComponent'
import {BrowserRouter, Routes, Route} from 'react-router-dom'

function App() {

  return (
    <>
      <BrowserRouter>
        <Header />
        <Layout>

          <Routes>
            {/* // http://localhost:3000 */}
              <Route path='/' element = { <ListEmployeeComponent />}></Route>
              {/* // http://localhost:3000/employees */}
              <Route path='/employees' element = { <ListEmployeeComponent /> }></Route>
              {/* // http://localhost:3000/add-employee */}
              <Route path='/add-employee' element = { <EmployeeComponent />}></Route>
              <Route path="/security" element={<Security />} />
              <Route path="/exchange" element={<MoneyExchange />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/dashboard" element={<AccountProfile />} />
              {/* // http://localhost:3000/edit-employee/1 */}
              <Route path='/edit-employee/:id' element = { <EmployeeComponent /> }></Route>
              {/* <Route path="/dashboard" element={<AccountProfile />} />
          <Route path="/transactions" element={<Transactions />} />
          <Route path="/pay" element={<Pay />} />
          <Route path="/receive" element={<Receive />} />
          <Route path="/exchange" element={<Exchange />} />
          <Route path="/recipients" element={<Recipients />} />
          <Route path="/crypto" element={<Crypto />} />
          <Route path="/deposit-money" element={<DepositMoney />} />
          <Route path="/withdraw-money" element={<WithdrawMoney />} />
          <Route path="/account" element={<Account />} />
          <Route path="/support" element={<Support />} />
          <Route path="/quit" element={<Quit />} /> */}
          </Routes>
          <TransferForm />
          {/* <Login />
          <Signup/> */}
          {/* <AddRecipientPage /> */}
          {/* <AddRecipientForm/> */}
        {/* <FooterComponent /> */}
        {/* <AccountProfile /> */}
        {/* <MoneyExchange/> */}
        </Layout>
      </BrowserRouter>
    </>
  )
}

export default App
