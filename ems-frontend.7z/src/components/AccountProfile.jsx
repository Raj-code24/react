// src/pages/Account.js

import { useState } from 'react';
import { FaCheckCircle, FaExclamationTriangle, FaEnvelope } from 'react-icons/fa';

const AccountProfile = () => {
  const [activeTab, setActiveTab] = useState('account');

  const account = {
    avatarUrl: 'https://via.placeholder.com/150',
    firstName: 'Alfred',
    lastName: 'Davis',
    email: 'alfred6598@gmail.com',
    phone: '(316) 555-0116',
    accountId: 'Rex49484',
    joined: 'Aug 25, 2021',
    confirmStatus: 80,
    emailConfirmed: false,
    phoneConfirmed: true,
    idUploaded: false,
    address: '2972 Westheimer Rd. Santa Ana, Illinois 85486',
  };

  return (
    
    <div className="account-page">
      <div className="profile-card">
        <img src={account.avatarUrl} alt="Avatar" className="avatar" />
        <h2>{account.firstName} {account.lastName}</h2>
        <p className="status">Active</p>
        <p><strong>Account ID:</strong> {account.accountId}</p>
        <p><strong>Joined:</strong> {account.joined}</p>
        <p><strong>Confirm status:</strong> {account.confirmStatus}%</p>
        <button className="logout-button">Logout</button>
        <button className="delete-button">Delete Account</button>
      </div>
      <div className="profile-details">
        <div className="tabs">
          <button onClick={() => setActiveTab('account')} className={activeTab === 'account' ? 'active' : ''}>Account</button>
          <button onClick={() => setActiveTab('security')} className={activeTab === 'security' ? 'active' : ''}>Security</button>
          <button onClick={() => setActiveTab('payment')} className={activeTab === 'payment' ? 'active' : ''}>Payment Methods</button>
          <button onClick={() => setActiveTab('notification')} className={activeTab === 'notification' ? 'active' : ''}>Notification</button>
        </div>
        {activeTab === 'account' && (
          <div className="tab-content">
            <h3>Your Avatar</h3>
            <p>Profile picture size: 400px x 400px</p>
            <input type="file" />
            <img src={account.avatarUrl} alt="Avatar" className="avatar-preview" />
            <div className="form-group">
              <label>First Name</label>
              <input type="text" value={account.firstName} readOnly />
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <input type="text" value={account.lastName} readOnly />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input type="email" value={account.email} readOnly />
              <button className="confirm-button">
                <FaEnvelope /> {account.emailConfirmed ? 'Email confirmed' : 'Email confirmation pending'}
              </button>
            </div>
            <div className="form-group">
              <label>Phone</label>
              <input type="tel" value={account.phone} readOnly />
              <button className="confirm-button">
                {account.phoneConfirmed ? <FaCheckCircle /> : <FaExclamationTriangle />} Phone number {account.phoneConfirmed ? 'confirm' : 'not confirmed'}
              </button>
            </div>
            <div className="form-group">
              <label>ID Confirmation documents</label>
              <input type="text" value={account.idUploaded ? 'Uploaded' : 'Not uploaded'} readOnly />
              <button className="confirm-button">
                {account.idUploaded ? <FaCheckCircle /> : <FaExclamationTriangle />} {account.idUploaded ? 'Person confirmed' : 'Person not confirmed'}
              </button>
            </div>
            <div className="form-group">
              <label>Address</label>
              <input type="text" value={account.address} readOnly />
            </div>
          </div>
        )}
        {activeTab === 'security' && (
          <div className="tab-content">
            <h3>Security Settings</h3>
            {/* Add your security settings form here */}
          </div>
        )}
        {activeTab === 'payment' && (
          <div className="tab-content">
            <h3>Payment Methods</h3>
            {/* Add your payment methods form here */}
          </div>
        )}
        {activeTab === 'notification' && (
          <div className="tab-content">
            <h3>Notification Settings</h3>
            {/* Add your notification settings form here */}
          </div>
        )}
      </div>
      <style jsx>{`
        .account-page {
          display: flex;
        }
        .profile-card {
          background: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
          width: 30%;
          text-align: center;
          margin-right: 20px;
        }
        .profile-details {
          background: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
          width: 70%;
        }
        .avatar {
          width: 100px;
          height: 100px;
          border-radius: 50%;
          object-fit: cover;
          margin-bottom: 10px;
        }
        .status {
          color: green;
          margin-bottom: 10px;
        }
        .tabs {
          display: flex;
          margin-bottom: 20px;
        }
        .tabs button {
          background: none;
          border: none;
          padding: 10px 20px;
          cursor: pointer;
        }
        .tabs button.active {
          background: #0070f3;
          color: #fff;
          border-radius: 8px;
        }
        .form-group {
          margin-bottom: 15px;
        }
        label {
          display: block;
          margin-bottom: 5px;
        }
        input {
          width: 100%;
          padding: 8px;
          box-sizing: border-box;
          border: 1px solid #ccc;
          border-radius: 4px;
        }
        .avatar-preview {
          width: 100px;
          height: 100px;
          border-radius: 50%;
          object-fit: cover;
          margin-top: 10px;
        }
        .confirm-button {
          display: flex;
          align-items: center;
          background: none;
          border: none;
          color: #666;
          cursor: pointer;
          padding: 0;
        }
        .confirm-button svg {
          margin-right: 5px;
        }
        .logout-button {
          background: #4CAF50;
          color: #fff;
          border: none;
          padding: 10px 20px;
          border-radius: 4px;
          cursor: pointer;
          margin-top: 10px;
        }
        .delete-button {
          background: #f44336;
          color: #fff;
          border: none;
          padding: 10px 20px;
          border-radius: 4px;
          cursor: pointer;
          margin-top: 10px;
        }
      `}</style>
    </div>
  );
};

export default AccountProfile;
