// src/pages/MoneyExchange.js

import React, { useState } from 'react';

const MoneyExchange = () => {
  const [sendAmount, setSendAmount] = useState(400.00);
  const [receiveAmount, setReceiveAmount] = useState(45162.98);
  const [deliveryMethod, setDeliveryMethod] = useState('Bank Transfer');
  const [bankPartner, setBankPartner] = useState('Dutch Bangla Bank');

  return (
    <div className="money-exchange">
      <h2>Money Exchange</h2>
      <div className="exchange-section">
        <div className="send">
          <label>You Send</label>
          <input 
            type="number" 
            value={sendAmount} 
            onChange={(e) => setSendAmount(e.target.value)} 
          />
          <p>Available Balance <strong>$30,700.00</strong></p>
          <select>
            <option value="USD">USD</option>
            {/* Add more currencies as needed */}
          </select>
        </div>
        <div className="switch">
          <button>⇄</button>
        </div>
        <div className="receive">
          <label>Recipient gets</label>
          <input 
            type="number" 
            value={receiveAmount} 
            readOnly 
          />
          <p>Today's rate: 1 GBP = 112.90745 BDT</p>
          <select>
            <option value="BDT">BDT</option>
            {/* Add more currencies as needed */}
          </select>
        </div>
      </div>
      <div className="details-section">
        <div className="detail">
          <label>Delivery method</label>
          <select value={deliveryMethod} onChange={(e) => setDeliveryMethod(e.target.value)}>
            <option value="Bank Transfer">Bank Transfer</option>
            {/* Add more delivery methods as needed */}
          </select>
        </div>
        <div className="detail">
          <label>Bank Transfer Partner</label>
          <select value={bankPartner} onChange={(e) => setBankPartner(e.target.value)}>
            <option value="Dutch Bangla Bank">Dutch Bangla Bank</option>
            {/* Add more bank partners as needed */}
          </select>
        </div>
      </div>
      <div className="summary-section">
        <div className="summary-item">
          <label>Estimated fee</label>
          <p>+0.33 GBP</p>
        </div>
        <div className="summary-item">
          <label>Transfer time</label>
          <p>Same Day</p>
        </div>
      </div>
      <div className="total-section">
        <div className="total-item">
          <label>Total To Pay</label>
          <p>400.99 GBP</p>
        </div>
        <div className="total-item">
          <label>Recipient gets</label>
          <p>45299.58 BDT</p>
        </div>
      </div>
      <button className="continue-button">Continue</button>
      <style jsx>{`
        .money-exchange {
          padding: 20px;
          background: #fff;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
          max-width: 800px;
          margin: 20px auto;
        }
        .exchange-section {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }
        .send, .receive {
          width: 45%;
        }
        .send input, .receive input {
          width: 100%;
          padding: 10px;
          margin-top: 10px;
          margin-bottom: 5px;
          border: 1px solid #ccc;
          border-radius: 4px;
          font-size: 16px;
        }
        .send select, .receive select {
          width: 100%;
          padding: 10px;
          margin-top: 10px;
          border: 1px solid #ccc;
          border-radius: 4px;
          font-size: 16px;
        }
        .switch button {
          background: #6C63FF;
          color: #fff;
          border: none;
          border-radius: 50%;
          padding: 10px;
          cursor: pointer;
        }
        .details-section {
          display: flex;
          justify-content: space-between;
          margin-bottom: 20px;
        }
        .detail {
          width: 45%;
        }
        .detail select {
          width: 100%;
          padding: 10px;
          margin-top: 10px;
          border: 1px solid #ccc;
          border-radius: 4px;
          font-size: 16px;
        }
        .summary-section {
          display: flex;
          justify-content: space-between;
          margin-bottom: 20px;
        }
        .summary-item {
          width: 45%;
        }
        .total-section {
          display: flex;
          justify-content: space-between;
          margin-bottom: 20px;
        }
        .total-item {
          width: 45%;
        }
        .continue-button {
          width: 100%;
          padding: 15px;
          background: #6C63FF;
          color: #fff;
          border: none;
          border-radius: 4px;
          font-size: 18px;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
};

export default MoneyExchange;
