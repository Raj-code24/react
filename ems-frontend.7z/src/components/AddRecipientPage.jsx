// pages/add-recipient.js

import AddRecipientForm from '../components/AddRecipientForm';

const AddRecipientPage = () => {
  return (
    <div>
      <h1>Add Recipient</h1>
      <AddRecipientForm />
    </div>
  );
};

export default AddRecipientPage;
