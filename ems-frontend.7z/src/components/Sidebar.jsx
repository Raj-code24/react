// src/components/Sidebar.js

import { FaTachometerAlt, FaExchangeAlt, FaMoneyBillWave, FaFileInvoiceDollar, FaUsers, FaBitcoin, FaRegMoneyBillAlt, FaMoneyCheckAlt, FaUser, FaQuestionCircle, FaSignOutAlt } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="logo">
        <img src="/logo.png" alt="Paylio" />
      </div>
      <nav>
        <ul>
          <li>
            <Link to="/dashboard">
              <FaTachometerAlt /> Dashboard
            </Link>
          </li>
          <li>
            <Link to="/transactions">
              <FaExchangeAlt /> Transactions
            </Link>
          </li>
          <li>
            <Link to="/pay">
              <FaMoneyBillWave /> Pay
            </Link>
          </li>
          <li>
            <Link to="/receive">
              <FaFileInvoiceDollar /> Receive
            </Link>
          </li>
          <li>
            <Link to="/exchange">
              <FaExchangeAlt /> Exchange
            </Link>
          </li>
          <li>
            <Link to="/recipients">
              <FaUsers /> Recipients
            </Link>
          </li>
          <li>
            <Link to="/crypto">
              <FaBitcoin /> Crypto
            </Link>
          </li>
          <li>
            <Link to="/deposit-money">
              <FaRegMoneyBillAlt /> Deposit Money
            </Link>
          </li>
          <li>
            <Link to="/withdraw-money">
              <FaMoneyCheckAlt /> Withdraw Money
            </Link>
          </li>
          <li>
            <Link to="/account">
              <FaUser /> Account
            </Link>
          </li>
          <li>
            <Link to="/support">
              <FaQuestionCircle /> Support
            </Link>
          </li>
          <li>
            <Link to="/quit">
              <FaSignOutAlt /> Quit
            </Link>
          </li>
        </ul>
      </nav>
      <style jsx>{`
        .sidebar {
          width: 250px;
          height: 100vh;
          background-color: #fff;
          box-shadow: 2px 0 5px rgba(0,0,0,0.1);
          padding: 20px;
          position: fixed;
        }
        .logo img {
          max-width: 100%;
          height: auto;
        }
        nav ul {
          list-style-type: none;
          padding: 0;
        }
        nav ul li {
          margin: 20px 0;
        }
        nav ul li a {
          text-decoration: none;
          color: #333;
          font-size: 16px;
          display: flex;
          align-items: center;
        }
        nav ul li a:hover {
          color: #0070f3;
        }
        nav ul li a svg {
          margin-right: 10px;
        }
      `}</style>
    </div>
  );
};

export default Sidebar;
