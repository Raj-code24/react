// src/components/Header.js
import { Accordion, Navbar, Container, Nav, Button, Dropdown, Image} from 'react-bootstrap';
import React, { useState } from 'react';
import { FaUserCircle } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState({ name: "John Doe" });

  const handleLogin = () => {
    // Handle login logic here
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    // Handle logout logic here
    setIsAuthenticated(false);
    setUser(null);
  };

  // return (
  //   <header className="header">
  //     <div className="logo">
  //       <Link to="/">MyApp</Link>
  //     </div>
  //     <nav className="nav-links">
  //       <Link to="/">Home</Link>
  //       <Link to="/about">About</Link>
  //       <Link to="/contact">Contact</Link>
  //       {isAuthenticated ? (
  //         <div className="profile-section">
  //           <FaUserCircle className="profile-icon" />
  //           <span>{user.name}</span>
  //           <button onClick={handleLogout} className="logout-button">Logout</button>
  //         </div>
  //       ) : (
  //         <div className="auth-buttons">
  //           <Link to="/login" className="login-button">Login</Link>
  //           <Link to="/signup" className="signup-button">Sign Up</Link>
  //         </div>
  //       )}
  //     </nav>
  //   </header>
  // );

  // return (
  //   <Navbar bg="light" expand="lg" className="shadow-sm">
  //     <Container>
  //       <Navbar.Brand href="#home">MyApp</Navbar.Brand>
  //       <Navbar.Toggle aria-controls="basic-navbar-nav" />
  //       <Navbar.Collapse id="basic-navbar-nav">
  //         <Nav className="me-auto">
  //           <Accordion className="me-3">
  //             <Accordion.Item eventKey="0">
  //               <Accordion.Header>Menu 1</Accordion.Header>
  //               <Accordion.Body>
  //                 <Nav.Link href="#home">Home</Nav.Link>
  //                 <Nav.Link href="#about">About</Nav.Link>
  //                 <Nav.Link href="#services">Services</Nav.Link>
  //               </Accordion.Body>
  //             </Accordion.Item>
            
  //           </Accordion>
          
  //           <Accordion>
  //           <Accordion.Item eventKey="1">
  //               <Accordion.Header>Menu 2</Accordion.Header>
  //               <Accordion.Body>
  //                 <Nav.Link href="#contact">Contact</Nav.Link>
  //                 <Nav.Link href="#faq">FAQ</Nav.Link>
  //                 <Nav.Link href="#support">Support</Nav.Link>
  //               </Accordion.Body>
  //             </Accordion.Item>
  //             </Accordion>
  //         </Nav>
  //         <Button variant="outline-primary" className="me-2">
  //           Log in
  //         </Button>
  //         <Button variant="primary">Sign up</Button>
  //       </Navbar.Collapse>
  //     </Container>
  //   </Navbar>
  // );

  return (
    <Navbar bg="light" expand="lg" className="shadow-sm px-4">
      <Navbar.Brand href="#home">MyApp</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ms-auto">
          <Dropdown align="end">
            <Dropdown.Toggle variant="light" id="dropdown-basic">
              <Image
                src="https://via.placeholder.com/30"
                roundedCircle
                className="me-2"
              />
              User Menu
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item href="#profile">Profile</Dropdown.Item>
              <Dropdown.Item href="#settings">Settings</Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item href="#logout">Logout</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
};

export default Header;
