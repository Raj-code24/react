// pages/signup.jsx

import React, { useState } from 'react';
import axios from 'axios';
import styles from '../components/Signup.module.css';

const Signup = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = (e) => {
    e.preventDefault();
    const apiUrl = process.env.NEXT_PUBLIC_API_URL;
    axios.post(`${apiUrl}/accounts/signup`, { firstName, lastName, email, password })
      .then(response => {
        console.log('Signup successful', response.data);
      })
      .catch(error => {
        console.error('There was an error signing up!', error);
      });
  };

  return (
    <div className={styles.signup}>
      <h2>Sign Up</h2>
      <form onSubmit={handleSignup}>
        <div className={styles.formGroup}>
          <label>First Name</label>
          <input
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
          />
        </div>
        <div className={styles.formGroup}>
          <label>Last Name</label>
          <input
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
          />
        </div>
        <div className={styles.formGroup}>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className={styles.formGroup}>
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className={styles.signupButton}>Sign up</button>
      </form>
    </div>
  );
};

export default Signup;
