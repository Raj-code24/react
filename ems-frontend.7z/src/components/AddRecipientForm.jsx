// components/AddRecipientForm.js

import { useState } from 'react';
import Select from 'react-select';
import axios from 'axios';

const AddRecipientForm = () => {
  const [formData, setFormData] = useState({
    companyType: 'Company',
    companyName: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    country: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSelectChange = (selectedOption) => {
    setFormData({ ...formData, country: selectedOption.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/api/recipients', formData);
      console.log(response.data);
      // Clear form or provide feedback to the user
    } catch (error) {
      console.error('There was an error submitting the form!', error);
    }
  };

  const countryOptions = [
    { value: 'Canada', label: 'Canada' },
    { value: 'USA', label: 'USA' },
    // Add more countries as needed
  ];

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Company Type</label>
          <div>
            <button
              type="button"
              className={formData.companyType === 'Company' ? 'active' : ''}
              onClick={() => setFormData({ ...formData, companyType: 'Company' })}
            >
              Company
            </button>
            <button
              type="button"
              className={formData.companyType === 'Individual' ? 'active' : ''}
              onClick={() => setFormData({ ...formData, companyType: 'Individual' })}
            >
              Individual
            </button>
          </div>
        </div>

        {formData.companyType === 'Company' && (
          <div className="form-group">
            <label>Company Name</label>
            <input
              type="text"
              name="companyName"
              value={formData.companyName}
              onChange={handleChange}
            />
          </div>
        )}

        <div className="form-group">
          <label>First Name</label>
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Last Name</label>
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Phone</label>
          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Country</label>
          <Select
            options={countryOptions}
            value={countryOptions.find(option => option.value === formData.country)}
            onChange={handleSelectChange}
          />
        </div>

        <button type="submit">Submit</button>
      </form>
      <style jsx>{`
        .form-container {
          background: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
          max-width: 400px;
          margin: 20px auto;
        }
        .form-group {
          margin-bottom: 15px;
        }
        label {
          display: block;
          margin-bottom: 5px;
        }
        input {
          width: 100%;
          padding: 8px;
          box-sizing: border-box;
          border: 1px solid #ccc;
          border-radius: 4px;
        }
        button {
          background: #4CAF50;
          color: #fff;
          border: none;
          padding: 10px 20px;
          border-radius: 4px;
          cursor: pointer;
        }
        button.active {
          background: #333;
        }
        button + button {
          margin-left: 10px;
        }
      `}</style>
    </div>
  );
};

export default AddRecipientForm;
