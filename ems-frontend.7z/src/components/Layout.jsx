// src/components/Layout.js

import Sidebar from './Sidebar';

const Layout = ({ children }) => {
  return (
    <div className="layout">
      <Sidebar />
      <div className="content">
        {children}
      </div>
      <style jsx>{`
        .layout {
          display: flex;
        }
        .content {
          margin-left: 250px; /* Same width as the sidebar */
          padding: 20px;
          width: 100%;
        }
      `}</style>
    </div>
  );
};

export default Layout;
