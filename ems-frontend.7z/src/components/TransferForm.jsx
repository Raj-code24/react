import React, { useState } from 'react';
import axios from 'axios';
import '../components/TransferForm.css'; // Importing the CSS file

function TransferForm() {
    const [amountSent, setAmountSent] = useState('');
    const [currencySent, setCurrencySent] = useState('EUR');
    const [amountReceived, setAmountReceived] = useState('');
    const [currencyReceived, setCurrencyReceived] = useState('BZD');
    const [exchangeRate, setExchangeRate] = useState(2.1967);
    const [fee, setFee] = useState(2.99);
    const [discount, setDiscount] = useState(-2.99);
    const [totalCost, setTotalCost] = useState('');

    const calculateTotalCost = () => {
        const total = parseFloat(amountSent) + fee + discount;
        setTotalCost(total.toFixed(2));
        setAmountReceived((amountSent * exchangeRate).toFixed(2));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const transfer = {
            amountSent: parseFloat(amountSent),
            currencySent: currencySent,
            amountReceived: parseFloat(amountReceived),
            currencyReceived: currencyReceived,
            exchangeRate: exchangeRate,
            fee: fee,
            discount: discount,
            totalCost: parseFloat(totalCost)
        };
        try {
            const response = await axios.post('http://localhost:8080/api/transfers', transfer);
            console.log(response.data);
        } catch (error) {
            console.error('There was an error creating the transfer!', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <label>
                You send:
                <input
                    type="number"
                    value={amountSent}
                    onChange={(e) => setAmountSent(e.target.value)}
                    onBlur={calculateTotalCost}
                />
                <select value={currencySent} onChange={(e) => setCurrencySent(e.target.value)}>
                    <option value="EUR">EUR</option>
                    {/* Add more currencies as needed */}
                </select>
            </label>
            <label>
                They receive:
                <input type="text" value={amountReceived} readOnly />
                <select value={currencyReceived} onChange={(e) => setCurrencyReceived(e.target.value)}>
                    <option value="BZD">BZD</option>
                    {/* Add more currencies as needed */}
                </select>
            </label>
            <p>Everyday rate: 1 EUR = {exchangeRate} BZD</p>
            <p>Fee: {fee} EUR</p>
            <p>Discount: {discount} EUR</p>
            <p>Total cost: {totalCost} EUR</p>
            <button type="submit">Get this rate</button>
        </form>
    );
}

export default TransferForm;
