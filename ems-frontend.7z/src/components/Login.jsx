// pages/login.jsx

import React, { useState } from 'react';
import axios from 'axios';
import styles from '../components/Login.module.css';
const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    const apiUrl = process.env.NEXT_PUBLIC_API_URL;
    axios.post(`${apiUrl}/accounts/login`, { email, password })
      .then(response => {
        console.log('Login successful', response.data);
      })
      .catch(error => {
        console.error('There was an error logging in!', error);
      });
  };

  return (
    <div className={styles.login}>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div className={styles.formGroup}>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className={styles.formGroup}>
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className={styles.loginButton}>Log in</button>
      </form>
    </div>
  );
};

export default Login;
