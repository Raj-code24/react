// src/pages/Security.js

import React, { useState } from 'react';

const Security = () => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  const handlePasswordChange = () => {
    // Handle password change logic
    console.log('Password changed');
  };

  return (
    <div className="security-page">
      <div className="profile-card">
        <img src="https://via.placeholder.com/150" alt="Avatar" className="avatar" />
        <h2>Alfred Davis</h2>
        <p className="status">Active</p>
        <p><strong>Account ID:</strong> Rex49484</p>
        <p><strong>Joined:</strong> Aug 25, 2021</p>
        <p><strong>Confirm status:</strong> 80%</p>
        <button className="logout-button">Logout</button>
        <button className="delete-button">Delete Account</button>
      </div>
      <div className="profile-details">
        <div className="tabs">
          <button className="active">Account</button>
          <button className="active">Security</button>
          <button>Payment Methods</button>
          <button>Notification</button>
        </div>
        <div className="tab-content">
          <h3>Two Factor Authentication</h3>
          <p>Two-Factor Authentication (2FA) can be used to help protect your account</p>
          <button className="enable-button">Enable</button>
          
          <h3>Change Password</h3>
          <p>You can always change your password for security reasons or reset your password in case you forgot it.</p>
          <button className="forgot-password-button">Forgot password?</button>
          
          <div className="form-group">
            <label>Current password</label>
            <input
              type="password"
              placeholder="Current password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>New password</label>
            <input
              type="password"
              placeholder="New password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Confirm New password</label>
            <input
              type="password"
              placeholder="Confirm New password"
              value={confirmNewPassword}
              onChange={(e) => setConfirmNewPassword(e.target.value)}
            />
          </div>
          <button className="update-password-button" onClick={handlePasswordChange}>Update password</button>

          <h3>Additional security</h3>
          <div className="additional-security">
            <div className="security-item">
              <p><strong>SMS recovery</strong></p>
              <p>Number ending with 1234</p>
              <button className="disable-sms-button">Disable SMS</button>
            </div>
            <div className="security-item">
              <p><strong>Authenticator App</strong></p>
              <p>Google Authenticator</p>
              <button className="configure-button">Configure</button>
            </div>
          </div>
        </div>
      </div>
      <style jsx>{`
        .security-page {
          display: flex;
        }
        .profile-card {
          background: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
          width: 30%;
          text-align: center;
          margin-right: 20px;
        }
        .profile-details {
          background: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
          width: 70%;
        }
        .avatar {
          width: 100px;
          height: 100px;
          border-radius: 50%;
          object-fit: cover;
          margin-bottom: 10px;
        }
        .status {
          color: green;
          margin-bottom: 10px;
        }
        .tabs {
          display: flex;
          margin-bottom: 20px;
        }
        .tabs button {
          background: none;
          border: none;
          padding: 10px 20px;
          cursor: pointer;
        }
        .tabs button.active {
          background: #0070f3;
          color: #fff;
          border-radius: 8px;
        }
        .form-group {
          margin-bottom: 15px;
        }
        label {
          display: block;
          margin-bottom: 5px;
        }
        input {
          width: 100%;
          padding: 8px;
          box-sizing: border-box;
          border: 1px solid #ccc;
          border-radius: 4px;
        }
        .tab-content {
          padding: 20px;
        }
        .enable-button,
        .forgot-password-button,
        .update-password-button,
        .disable-sms-button,
        .configure-button {
          display: block;
          margin-top: 10px;
          padding: 10px 20px;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          background: #0070f3;
          color: #fff;
        }
        .additional-security {
          margin-top: 20px;
        }
        .security-item {
          margin-bottom: 20px;
        }
      `}</style>
    </div>
  );
};

export default Security;
